const mongoose = require('mongoose');
const Bix = require('../bix');

const Schema = mongoose.Schema;

const collectionSchema = new Schema({
    "name": String,
    "stbno": String,
    "vcNo": String,
    "isSamePack": Boolean,
    "amount": Number,
    "time": Date,
    "period": {type:Number,default:30},
    "products": [String],
    "rechargeFinalStatus":{type:String,default:'Pending'},
    "rechargeMessage":{type:String,default:'N/A'},
    "visited":{type:Boolean,default:false},
    "rechargeExecuted":{type:Boolean,default:false},
    "sitiRechargeTime":Date,
    "sitiCustomerAmount":Number,
    "existingLcoAmount":Number,
    "enteredLcoAmount":Number,
    "boxStatusBeforeRecharge":{type:String,default:'N/A'}
})
collectionSchema.index({ stbno: 1, time: 1}, { unique: true });

const Collection = mongoose.model('Collection', collectionSchema);
Bix.list['collection'] = Collection;

module.exports = Collection;