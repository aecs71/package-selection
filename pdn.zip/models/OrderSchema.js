const mongoose=require('mongoose');
const Bix=require('../bix');
const Schema=mongoose.Schema;

const OrderSchema=new Schema({
    "email":String,
    "custId":String,
    "stbNo":String,
    "orderId":String,
    "txnDate":{type:Date,default:Date.now},
    "amount":String,
    "txnStatus":String,
    "mode":String,
    "from":String,
    "to":String,
    "recordPaymentResp":Object,
    "generateBillResp":Object,
    "reachedProcessing":Boolean,
    "G_TXNID":String,
    "G_BANKTXNID":String,
    "G_TXNTYPE":String,
    "G_GATEWAYNAME":String,
    "G_RESPCODE":String,
    "G_RESPMSG":String,
    "G_BANKNAME":String,
    "G_PAYMENTMODE":String,
    "G_REFUNDAMT":String,
    "G_TXNDATE":String,
    "G_TXNAMOUNT":String
});

const Orders=mongoose.model('orders',OrderSchema);
Bix.list['order']=Orders;

module.exports=Orders;