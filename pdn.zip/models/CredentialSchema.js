const mongoose = require('mongoose');
const Bix = require('../bix');

const Schema = mongoose.Schema;

const credentialSchema = new Schema({
    "key": String,
    "value": String,
    "id": Number,
})


const Credentials = mongoose.model('Credentials', credentialSchema);
Bix.list['credentials'] = Credentials;

module.exports = Credentials;