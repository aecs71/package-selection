var https = require('https');
var tls = require('tls');
var fs = require('fs');
var http=require('http')
function startHttpsServer(pubghub,app,callback){
  
	var ssl = pubghub.get('ssl');
	var host = pubghub.get('ssl host') || pubghub.get('host');
    var port = pubghub.get('ssl port');
    /*var options={};
    if (pubghub.get('ssl cert') && fs.existsSync(pubghub.get('ssl cert'))) {
		options.cert = fs.readFileSync(pubghub.get('ssl cert'));
	}
	if (pubghub.get('ssl key') && fs.existsSync(pubghub.get('ssl key'))) {
		options.key = fs.readFileSync(pubghub.get('ssl key'));
    } */
  
    //var server = https.createServer(options,app);
   var server = http.createServer(app);
    server.listen(port,host,(err)=>{
        console.log("Secure server started on: "+'https://' + host + ':' + port);
        callback(err)
    })


}
module.exports=startHttpsServer;