// var qs = require("querystring");
// var http = require("https");
const axios = require('axios');
// const cheerio = require('cheerio')
let moment=require('moment')

// const opt = {
//   headers: {
//     "connection": "keep-alive",
//     "upgrade-insecure-requests": "1",
//     "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36",
//     "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
//     "sec-fetch-site": "none",
//     "sec-fetch-mode": "navigate",
//     "accept-encoding": "gzip, deflate, br",
//     "accept-language": "en-GB,en;q=0.9,hi-IN;q=0.8,hi;q=0.7,en-US;q=0.6",
//     "cache-control": "no-cache",
//     "cookie": 'XSRF-TOKEN=eyJpdiI6InhpQThPM2NlT3J3eDdpeHg1YllNMWc9PSIsInZhbHVlIjoiMzJ6ekpHWlBYNUpBWVhVamJTY2thQnNOQzQxN0F1RHdHcTFQZU9aUW1BSGkzbnpmOGNBd1A0elZTTjZtWHVjbyIsIm1hYyI6IjYwMThmNzQzY2JlN2RlYmZhYjQ2NmIzNmI2MzMwZmViOTNmMzlmODVkZTFkNDk0MTUzNTM5ZTI5MzFiMThjMWMifQ%3D%3D;bix42_session=eyJpdiI6Imh6R2xTVjV0dDU4SE1QSFBlbURIdkE9PSIsInZhbHVlIjoiYjUzalVycGxQWm1jaDNyS0pUeDQ5bFpibmV5WXdcLzF1MlFYakI5T1ZnSVpSS2lQYm5YQVdZXC85VXhyWDZabGxVIiwibWFjIjoiZmI0NzdkZjQ4YWY3NTJmZmE0MTY4NmZiZTQ2YTI1ZTVkOWMwMmYwODBhYmEwN2U1Y2FjYjQ0ZTA0MGU3MTFlMiJ9'
//   },

// }
// var options = {
//   headers: {
//     "connection": "keep-alive",
//     "cache-control": "no-cache",
//     "origin": "https://www.bix42.com",
//     "upgrade-insecure-requests": "1",
//     "content-type": "application/x-www-form-urlencoded",
//     "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36",
//     "sec-fetch-user": "?1",
//     "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
//     "sec-fetch-site": "same-origin",
//     "sec-fetch-mode": "navigate",
//     "referer": "https://www.bix42.com/login",
//     "accept-encoding": "gzip, deflate, br",
//     "accept-language": "en-GB,en;q=0.9,hi-IN;q=0.8,hi;q=0.7,en-US;q=0.6",
//     "cookie": 'XSRF-TOKEN=eyJpdiI6ImU3THRITVlQNzE5Z0JQdVB4RVY3eVE9PSIsInZhbHVlIjoiT241YUhibmlTaGI3ajVVVVB0T0JxMTNkbFlQNU5aclIwT0tDMUNxTXZqcVwvSzBnbE9HMjhrTDJCVzV0SUR3MVUiLCJtYWMiOiIwNmUyMmNiYmEwODdkMGYwMDQ4ZjBkMTJjYjdlNzkwODM4ZGJjNjA3YjI0MDc4NzM1ZTUyNDg4NDc0MGU2NGRmIn0%3D;bix42_session=eyJpdiI6ImFzY1FNWlkxZmszM3lmVk11aUd2OWc9PSIsInZhbHVlIjoiWU8ySWk0OUNHRVFzUnowYjFxcHlKOUdzQ0Z6R3NjTitmYTBMcVBGRnBycmlaODR0eTNwT01ndmZOZFlWMW5BdCIsIm1hYyI6ImQ0YzkyYWJjNmM0NjZiODY3MWI5M2RkZTRhNWY4ZTFmNWUyOTM2MjExY2M3MmVmMDYxYjBmY2U0OTNlMzdjMjQiQ%3D%3D',
//   }
// };

// let setCookie;
// let token;
//  axios.get('https://www.bix42.com/web/dashboard?r=5', opt).then(resp => {
//   setCookie = resp.headers['set-cookie'];
//   const $ = cheerio.load(resp.data)
//   token = $("input[name=_token]").attr('value');
//   let cookie = setCookie[0].split(';')[0]
//   let cok2 = setCookie[1].split(';')[0]
//   let finalCookie = cookie + ';' + cok2;
//   opt.headers.cookie = finalCookie
//   console.log(token);
//   console.log(opt);
// }).catch(err => console.log(err));
 
/* const req=require('./curl');
const a= req().then((data)=>console.log(data)).catch(err=>console.error(err)) */
let timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
console.log(timestamp);
let d=new Date();
console.log(d)
console.log(moment())