const axios = require('axios');

var options = {
  method: 'POST',
  url: 'https://www.bix42.com/web/balance/index',
  headers:
  {
    'cache-control': 'no-cache',
    Connection: 'keep-alive',
    Cookie: 'XSRF-TOKEN=eyJpdiI6Ik1Fa00wVjhZVUVvZ1QwUjZ0UmNHYWc9PSIsInZhbHVlIjoidVEyQjBaTVpyTVpVV2hZMjB6dEZMSkVHYVBrOFZFTHRrdVJHZ2NTYTA5RzFPOGVRNnpMOHZEM1NlRWhzRjFDUyIsIm1hYyI6IjBjNGM5ZDZhZmVlOTU1NzA2ZWVlY2FiOTFkNDg2NDZjZDdlMDU3YjA5NWYzNjRiMjRkMjZiYmUxMjI3ZjdiN2IifQ%3D%3D; laravel_session=eyJpdiI6IlZBNlVOMkRoNzBoT1hUQlZoQlA4ZlE9PSIsInZhbHVlIjoiTGw4MVd5RkVSQjExQTlQa2IzQXIwRitNYmNlY1V5WDdxRUxqcGZJNzM3MmNkTjdtWXc5U2tZNk1iTHZNaXNXTCIsIm1hYyI6ImUxMWMyYTc4OTE1NGI1ZmUyMGVlN2I5MGM1NWEzYmM4OGYxZjU2OGM2NDllZTJmYmU4OGQwOWJmMDE2MjFjMGMifQ%3D%3D',
    'Content-Length': '2',
    'Accept-Encoding': 'gzip, deflate',
    Host: 'www.bix42.com',
    'Postman-Token': '7ce28192-e53a-46a6-a5a9-a9cefc8f8210,ac5584fa-6841-49e7-aae0-b9b0764a2ab0',
    'Cache-Control': 'no-cache',
    Accept: '*/*',
    'User-Agent': 'PostmanRuntime/7.17.1',
    'x-xsrf-token': 'eyJpdiI6ImZxUmI1dmIyTUxzYkxicjFNT2lUNkE9PSIsInZhbHVlIjoiZDUrMWNyMmFoMmxIa2lmUUlkMWQ4UEJ6bUNlUHdpVkZxK1FaWGZISTlEbDIrYTkwU1B1MU5ERVgzY0sxVmYzZCIsIm1hYyI6ImQ4MzYxOTkxN2E2YjBkMTQ5MTE3MGUwZWI4Y2VhN2I5NDk4MWYxMDAxYjQwZmJmYWZmOGM2OGM2NjEzZmQ1MDkifQ==',
    'Content-Type': 'application/json;charset=UTF-8'
  },
  json: { "customer_id": 261016, "page": 1 }
};
const bixIsLoggedIn = (cookie, xsrf, csrf) => {
  const config = {
    headers:
    {
      'cache-control': 'no-cache',
      Connection: 'keep-alive',
      Cookie: cookie,
      'Content-Length': '2',
      'Accept-Encoding': 'gzip, deflate',
      Host: 'www.bix42.com',
      'Postman-Token': '7ce28192-e53a-46a6-a5a9-a9cefc8f8210,ac5584fa-6841-49e7-aae0-b9b0764a2ab0',
      'Cache-Control': 'no-cache',
      Accept: '*/*',
      'User-Agent': 'PostmanRuntime/7.17.1',
      'x-xsrf-token': xsrf,
      'x-csrf-token': csrf,
      'Content-Type': 'application/json;charset=UTF-8'
    }
  }
  return new Promise((resolve, reject) => {
    axios.post(`https://www.bix42.com/web/login`, {}, config)
      .then(function (response) {
        resolve(true)
      })
      .catch(function (error) {
        if (error && error.response && error.response.status == 419) {
          resolve(false);
        }
        else
          reject(error)
      });
  })
}
const bixRequest = (cookie, xsrf, path, reqData, csrf) => {
  const config = {
    headers:
    {
      'cache-control': 'no-cache',
      Connection: 'keep-alive',
      Cookie: cookie,
      'Content-Length': '2',
      'Accept-Encoding': 'gzip, deflate',
      Host: 'www.bix42.com',
      'Postman-Token': '7ce28192-e53a-46a6-a5a9-a9cefc8f8210,ac5584fa-6841-49e7-aae0-b9b0764a2ab0',
      'Cache-Control': 'no-cache',
      Accept: '*/*',
      'User-Agent': 'PostmanRuntime/7.17.1',
      'x-xsrf-token': xsrf,
      'x-csrf-token': csrf,
      'Content-Type': 'application/json;charset=UTF-8'
    }
  }
  /*  const newConfig={
     headers: {
       'Accept': 'application/x.merapaper.v5+json',
       'Content-Type': 'application/json',
       'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjUzODQsImlzcyI6Imh0dHA6Ly93d3cubWVyYXBhcGVyLmNvbS9hcGkvYXV0aC9sb2dpbiIsImlhdCI6MTU3ODA1OTAwMywiZXhwIjoxNjA5NTk1MDAzLCJuYmYiOjE1NzgwNTkwMDMsImp0aSI6IjFIckRXSDB4Sk5VQ0wxc24ifQ.vu4W5LSpegEYpCykvH9c62Av5q7zy5egJUTOJByDDG4',
       'Host': 'www.merapaper.com',
       'User-Agent': 'okhttp/3.10.0'
     }
   }; */
  return new Promise((resolve, reject) => {
    axios.post(`https://www.bix42.com/${path}`, reqData, config)
      .then(function (response) {
        resolve(response.data)
      })
      .catch(function (error) {
        reject(error);
      });
  })
}
const bixMobileRequest=(path,reqData,v)=>{
  const mobileConfig={
    headers: {
      'Accept': `application/x.merapaper.v${v}+json`,
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.BIX_MOB_TOKEN}`,
      'Host': 'www.merapaper.com',
      'User-Agent': 'okhttp/3.10.0'
    }
  }; 
  return new Promise((resolve, reject) => {
    axios.post(`http://www.merapaper.com/api/${path}`, reqData, mobileConfig)
      .then(function (response) {
        resolve(response.data)
      })
      .catch(function (error) {
        reject(error);
      });
  })
}
module.exports = {
  bixIsLoggedIn: bixIsLoggedIn,
  bixRequest: bixRequest,
  bixMobileRequest:bixMobileRequest
};
