const server = require('./server');
const services = require('./services');
const mapPackSimilarityResponse = async (data, cookie, xsrf, path,csrf) => {
    let billPast={products:[]}
    const billData = data.data;
    const filBillData = billData.filter(i => i.txn_type_id == 1).slice(0, 2);
    const billCurrent = await services.packageCompare(cookie, xsrf, filBillData[0].txn_id,csrf);
    if(filBillData.length>1)
      billPast = await services.packageCompare(cookie, xsrf, filBillData[1].txn_id,csrf);
    const billCurrentProductIds = billCurrent.products.map(i => i.product_id);
    const billPastProductIds = billPast.products.map(i => i.product_id);
    const pastBillData=filBillData[1]||{}
    const isSamePack = (JSON.stringify(billCurrentProductIds.sort()) == JSON.stringify(billPastProductIds.sort()))
    const productNames=billCurrent.products.map(i=>i.product_name)
    return { id: filBillData[0].customer_id, isSamePack, period: billCurrent.products[0].no_days,amount:filBillData[0].txn_amount,products:productNames,time:filBillData[0].txn_timestamp };
}
const mapTodaysCustomerResponse = (data) => {
    const obj = {};
    const promise = [];
    server.getPackSimilarityStatus()
    data.map(i => {
        promise.push(server.getPackSimilarityStatus(i.customer_id));
    })
    Promise.all(promise).then((val) => {
        console.log(val);
    })
}
const finalCustomerMapper = (packageData, customerData, rechargeData) => {
    const moreThanOneMonth = [];
    const obj = { packData: [], moreThanOneMonth: [] };
    const packResp = rechargeData.map(i => {
        const cusObj = customerData.find(item => {
            return item.customer[0].id == i.id
        }) || {};
        const simObj = packageData.find(item => i.id == item.id) || {};
        const stbNo = i.stb_no?i.stb_no.replace(/[^a-zA-Z0-9 ]/g, ""):'';
        const cardNo = i.card_no?i.card_no.replace(/[^a-zA-Z0-9 ]/g, ""):'';
          if (simObj.period > 30){
             moreThanOneMonth.push({ name:i.name,stbno:stbNo,vcNo:cardNo,isSamePack: simObj.isSamePack,amount:simObj.amount,time:simObj.time,period:simObj.period,products:simObj.products }); 
             return {}
          }
        return { name:i.name, stbno: stbNo, vcNo: cardNo,isSamePack: simObj.isSamePack,amount:simObj.amount,time:simObj.time,products:simObj.products,period:simObj.period }
    })
    obj.packData = packResp.filter(val=>Object.keys(val).length!=0);
    obj.moreThanOneMonth = moreThanOneMonth;
    return obj;
}
module.exports = {
    mapPackSimilarityResponse: mapPackSimilarityResponse,
    mapTodaysCustomerResponse: mapTodaysCustomerResponse,
    finalCustomerMapper: finalCustomerMapper
}