const axiosreq = require('./axiosreq');
const packageCompare = async (cookie, xsrf, txnId,csrf) => {
    const path = 'web/balance/bill';
    const reqData = { txn_id: txnId }
    const data = await axiosreq.bixRequest(cookie, xsrf, path, reqData,csrf);
    return data;
}

module.exports = {
    packageCompare: packageCompare,
}