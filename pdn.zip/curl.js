const { Curl } = require('node-libcurl');
const cheerio = require("cheerio");
const curl = new Curl();
const axios = require('axios');
const cookie = require('cookie');
var fs = require('fs');
let htmlResponse;
let bixCookie;
const getBixCredentials = () => {
    return new Promise((resolve, reject) => {
        const dashboardFirstReq = (curl, Curl) => {
            return new Promise((resolve, reject) => {
                curl.setOpt('URL', 'https://www.bix42.com/web/dashboard?r=5');
                curl.setOpt('FOLLOWLOCATION', true);
                curl.setOpt('COOKIEFILE', './cookie.txt')
                curl.setOpt('COOKIEJAR', './cookie.txt')
                curl.on('end', function (statusCode, data, headers) {
                    console.log(data)
                    const $ = cheerio.load(data);
                    const token = $('input[name=_token]').prop('value');
                    //  this.close();
                    resolve(token)

                })
                curl.on('error', (error) => { console.log("on error"); curl.close.bind(curl); reject(error) });
                curl.perform();
            })

        }
        const loginRequest = (curl, Curl, token) => {
            return new Promise((resolve, reject) => {
                curl.setOpt('CUSTOMREQUEST', "POST");
                curl.setOpt('URL', 'https://www.bix42.com/login');
                curl.setOpt('FOLLOWLOCATION', true);
                curl.setOpt('COOKIEFILE', './cookie.txt')
                curl.setOpt('COOKIEJAR', './cookie.txt')
                curl.setOpt(Curl.option.HTTPHEADER,
                    ['authority: www.bix42.com', 'cache-control: max-age=0', 'origin: https://www.bix42.com', 'upgrade-insecure-requests: 1'
                        , 'content-type: application/x-www-form-urlencoded',
                        'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',
                        'sec-fetch-user: ?1', 'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                        'sec-fetch-site: same-origin', 'sec-fetch-mode: navigate', 'referer: https://www.bix42.com/login', 'accept-encoding: gzip, deflate, br',
                        'accept-language: en-GB,en-US;q=0.9,en;q=0.8'])
                const postData = `_token=${token}&role=5&email=8294991200&password=123456p`;

                curl.setOpt('POSTFIELDS', postData);
                curl.on('end', function (statusCode, ndata, headers) {
                    console.log('2nd:' + ndata)
                    const c = headers[0]['Set-Cookie']
                    let str = '';
                    c.forEach((element, i) => {
                        str = str + element.split(';')[0] + ';'
                    });
                    // const co = c[0].split(';') + c[1].split(';')
                    // const c = cookie.parse(headers[0]['Set-Cookie']);
                    bixCookie = str;
                    this.close()
                    resolve(ndata);
                });
                curl.on('error', (error) => { curl.close.bind(curl); reject(error) });
                curl.perform();
            })

        }

        var filePath = './cookie.txt';
        if (fs.existsSync(filePath)) {
            console.log('exists')
            fs.unlinkSync(filePath);
            console.log('deleted')
        }
        console.log('requesting')
        dashboardFirstReq(curl, Curl).then((data) => {
            loginRequest(curl, Curl, data).then(() => {
                const options = {
                    headers:
                    {
                        'cache-control': 'no-cache',
                        cookie: bixCookie,
                    }

                }
                axios.get(`https://www.bix42.com/web/dashboard?r=5`, options).then(resp => {
                    const $ = cheerio.load(resp.data);
                    const csrf = $('meta[name=csrf-token]').prop('content');
                    resolve({ bixCookie, csrf });
                }).catch(err => { reject(err) })
            }).catch(err => { reject(err) })
        }).catch(err => { reject(err) })

    })
}





module.exports = getBixCredentials;
