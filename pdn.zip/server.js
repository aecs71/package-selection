const axiosReq = require('./axiosreq');
const bixMapper = require('./bixMapper');
const moment = require('moment');
const bixCredentials = require('./curl');
//const Credentials= this.getSchema('credentials')
let cookie = ''; //= Credentials.findOne({key:'cookie'});
let xsrf = ''; //= Credentials.findOne({key:'csrf'});
let csrf = '';
const path = 'web/balance/index'
const getPackSimilarityStatus = async (custId) => {
    try {
        const reqData = { customer_id: custId, page: 1 };
        const data = await axiosReq.bixRequest(cookie, xsrf, path, reqData,csrf);
        const resp = bixMapper.mapPackSimilarityResponse(data, cookie, xsrf, path,csrf);
        return resp;
    }
    catch (error) {
        throw error;
    }
}
const getSingleCustomerDetails = async (custId) => {
    try {

        const path = 'web/customers/single-customer';

        const reqData = { customer_id: custId }
        const data = await axiosReq.bixRequest(cookie, xsrf, path, reqData,csrf);
        return data;
    }
    catch (err) {
        throw err;
    }
}

const getTodaysCustomer = async (bix) => {
    try {
        const Credentials = bix.getSchema('credentials');
        const cookieObj = await Credentials.findOne({ key: 'cookie' },{value:1,_id:0});
        cookie=cookieObj?cookieObj.value:'';
        if (!cookie)
            throw new Error("first execution");
        xsrf = cookie.split(';')[0]
        const csrfObj = await Credentials.findOne({ key: 'csrf' });
        csrf=csrfObj?csrfObj.value:''
        const isLoggedIn = await axiosReq.bixIsLoggedIn(cookie, xsrf, csrf);
        if (!isLoggedIn) {
            const cred = await bixCredentials();
            cookie = cred.bixCookie;
            xsrf = cookie.split(';')[0]
            csrf = cred.csrf;
            await Credentials.updateOne({ key: 'cookie' }, { $set: { value: cred.bixCookie } }, { upsert: true })
            await Credentials.updateOne({ key: 'xsrf' }, { $set: { value: xsrf } }, { upsert: true })
            await Credentials.updateOne({ key: 'csrf' }, { $set: { value: cred.csrf } }, { upsert: true })
        }
        const path = 'web/report/detail-dashboard-stats';
        const todayDate = moment().format('YYYY-MM-DD')
        const reqData = {
            from_date: todayDate,
            to_date: todayDate
        }
        const rechargeData = await axiosReq.bixRequest(cookie, xsrf, path, reqData,csrf);
        const promise = [];
        rechargeData.data.map(i => {
            promise.push(getPackSimilarityStatus(i.id));
        })
        const packSimilarityData = await Promise.all(promise);
        // const resp=bixMapper.mapTodaysCustomerResponse(allData);
        const customerPromise = [];
        packSimilarityData.map(i => customerPromise.push(getSingleCustomerDetails(i.id)));
        const customerData = await Promise.all(customerPromise);
        const resp = bixMapper.finalCustomerMapper(packSimilarityData, customerData, rechargeData.data);
        return resp;

    }
    catch (err) {
        /* const status = err.response ? err.response.status : null;
        if (status == 419 || status == 500 || err.message == 'first execution') {

           
        }
        else */
        throw err;
    }

}

//getPackSimilarityStatus(261016);

module.exports = {
    getPackSimilarityStatus: getPackSimilarityStatus,
    getTodaysCustomer: getTodaysCustomer,
}
