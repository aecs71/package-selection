require('dotenv').config()
var Bix = require('./bix');
Bix.import('models');
Bix.start();
console.log(process.env)
const collections = Bix.getSchema('collection')