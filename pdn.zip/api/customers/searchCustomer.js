const getBixCredentials = require('../../lib/getBixCredentials');
const axiosReq = require('../../axiosreq');
const moment = require('moment');
searchCustomer = async (req, res) => {
    try {
        var bix = req.bix;
        const { cookie, csrf, xsrf } = await getBixCredentials(bix);
        const searchTxt = req.body.searchTxt;
        const reqBody = {
            area: "",
            bill_type: "",
            date_search: "",
            excel: "",
            order: false,
            order_by: "id",
            search: searchTxt,
            status: "",
            version_number: 0
        }
        const details = await axiosReq.bixRequest(cookie, xsrf, 'web/customers/index', reqBody, csrf);
        if (details.customers.total == 0 || (details && details.customers.total > 1))
            throw Error("Incorrect Stb or Card No.Please check and enter again");
        const validCustomerDetails = details.customers.data[0];
        const lastBillDate = validCustomerDetails.last_bill_date;
        const billBody = { from_date: moment(lastBillDate).add(1, 'd').format('YYYY-MM-DD'), to_date: moment(lastBillDate).add(30, 'd').format('YYYY-MM-DD'), period: 1, customer_id: validCustomerDetails.id }
        const generatedBill = await axiosReq.bixRequest(cookie, xsrf, 'web/balance/generatebill-from-date', billBody, csrf)
        res.send({ customerDetails: validCustomerDetails, bill: generatedBill });
    }
    catch (error) {
        res.status(500).send(error.message);
    }

}
module.exports = searchCustomer;
