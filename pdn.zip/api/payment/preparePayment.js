const checksum_lib = require('./checksum.js');
const callbackUrl=require('../../lib/callbackUrl');
async function preparePayment(req, res) {
	try{
	var bix = req.bix;
	console.info('inside prepare payment');
    console.info('preparePayment-got user id :'+req.query.id);
    console.info('preparePayment-got card no:'+req.query.cardNo);
	console.info("Preparepayment:got ree obj:"+req.query);
	var Orders = bix.getSchema('order');
	var ordersObj = {};
	let {id,cardNo,stbNo,amount,from,to}=req.query;
	stbNo= stbNo?stbNo.replace(/[^a-zA-Z0-9 ]/g, ""):'';
	cardNo= cardNo?cardNo.replace(/[^a-zA-Z0-9 ]/g, ""):'';
	if(isNaN(id)||isNaN(amount)||!from ||!to)
		throw Error("Valid details not found.Please contact your cable operator.")
	ordersObj['custId'] = id;
	ordersObj['cardNo'] = cardNo||'';
	ordersObj['stbNo'] = stbNo||'';
	ordersObj['orderId']= req.query.id + Math.random().toString(36).substring(2);
	ordersObj['amount'] = amount||'';
	ordersObj['from']=from;
	ordersObj['to']=to;
	ordersObj['txnStatus'] = 'Preparing';
	ordersObj['mode'] = 'Paytm';
	var currentOrder = new Orders(ordersObj);
	var c_url=callbackUrl();
	currentOrder.save((err, doc) => {
		console.info('inside current order');
		if (err) return res.status(500).send("There was a problem with the payment process");
		var PAYTM_MID= process.env.PAYTM_MID;
		var PAYTM_WEB=process.env.PAYTM_WEB;
		var PAYTM_KEY=process.env.PAYTM_KEY;
		console.info('order created');
		var params = {}
		params['MID'] =PAYTM_MID
		params['WEBSITE'] = PAYTM_WEB;
		params['CHANNEL_ID'] = 'WAP';
		params['INDUSTRY_TYPE_ID'] = 'Retail';
		params['ORDER_ID'] = doc.orderId;
		params['CUST_ID'] = doc.custId;
		params['TXN_AMOUNT'] = doc.amount;
		params['CALLBACK_URL'] = c_url;
		params['EMAIL'] = doc.email||'';
		
		checksum_lib.genchecksum(params, PAYTM_KEY, function (err, checksum) {
			if(err)
			return res.status(500).send(err.message);
			var txn_url = process.env.PAYTM_TXN_URL;//?"https://securegw-stage.paytm.in/theia/processTransaction":'https://securegw.paytm.in/theia/processTransaction' // for staging
			// var txn_url = "https://securegw.paytm.in/theia/processTransaction"; // for production

			var form_fields = "";
			for (var x in params) {
				form_fields += "<input type='hidden' name='" + x + "' value='" + params[x] + "' >";
			}
			form_fields += "<input type='hidden' name='CHECKSUMHASH' value='" + checksum + "' >";

			res.writeHead(200, { 'Content-Type': 'text/html' });
			res.write('<html><head><title>Merchant Checkout Page</title></head><body><center><h1>Please do not refresh this page...</h1></center><form method="post" action="' + txn_url + '" name="f1">' + form_fields + '</form><script type="text/javascript">document.f1.submit();</script></body></html>');
			res.end();
			console.info('payment request forwaded to paytm');
		});



	})
}
catch(err){
	res.status(500).send(err.message)
}

}
module.exports = preparePayment;