const checksum_lib = require('./checksum.js');
var https = require('https');
var updateOrder = require('../order/updateOrder');
function processPayment(req, res) {
    try {
        var post_data = req.body;
        console.log(post_data);
    
        var bix = req.bix;
        const Orders = bix.getSchema('order');
        Orders.updateOne({ orderId: post_data.ORDERID }, {
            $set: { reachedProcessing:true,G_RESPMSG: post_data.RESPMSG, txnStatus: post_data.STATUS
            }
        }).then(doc=>{
            console.log("updated process payment doc")}).catch(err=>{console.log("error while updating process payment")})
        var checksumhash = post_data.CHECKSUMHASH;
        console.info('inside process payment');
        var PAYTM_KEY = process.env.PAYTM_KEY
        var result = checksum_lib.verifychecksum(post_data, PAYTM_KEY, checksumhash);
        console.info('received post checksumhash' + ' checksumhash=' + checksumhash);
        var params = { "MID": process.env.PAYTM_MID, "ORDERID": post_data.ORDERID };
        checksum_lib.genchecksum(params, PAYTM_KEY, function (err, checksum) {
            console.info('inside genchecksum' + ' checksum=' + checksum);
            if (err)
                throw Error("Unable to verify checksum");
            params.CHECKSUMHASH = checksum;
            post_data = 'JsonData=' + JSON.stringify(params);
            console.info('verify post data= ' + post_data);
            var options = {
                hostname: process.env.PAYTM_HOSTNAME, // for staging
                // hostname: 'securegw.paytm.in', // for production
                port: 443,
                path: '/merchant-status/getTxnStatus',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Content-Length': post_data.length
                }
            };


            // Set up the request
            var response = "";
            var post_req = https.request(options, function (post_res) {
                post_res.on('data', function (chunk) {
                    response += chunk;
                });
                post_res.on('error',(err)=>{
                    console.log(err)
                    throw err;
                })
                post_res.on('end', async function () {
                    console.log('S2S Response: ', response, "\n");
                    var html = ''
                    var _result = JSON.parse(response);
                    html += "<b>Status Check Response</b><br>";
                    for (var x in _result) {
                        html += x + " => " + _result[x] + "<br/>";
                    }
                    let updateDoc;
                    try{
                     updateDoc = await updateOrder(req, _result)/* , function (err, doc) { */
                    }
                    catch(error){
                        return res.status(500).send("There was a problem with the payment process.In case the amount was deducted it will be refunded back to you within 7 business days.For any queries contact your cable operator");
                    }
                        console.info('inside update order');
                    if (updateDoc.G_RESPCODE) {
                        //const respData=JSON.stringify({repCode:updateDoc.G_RESPCODE,txnId:updateDoc.orderId})
                        //if (err) return res.status(500).send("There was a problem with the payment process.In case the amount was deducted it will be refunded back to you within 7 business days.For any queries contact your cable operator");
                        console.info('inside order successful');
                        res.writeHead(200, { 'Content-Type': 'text/html' });
                        res.write(`<html><body>${html}<script>;(function(){
                    
                         window.addEventListener("DOMContentLoaded", function(event) {
                       
                        setTimeout(function () {
                            window.ReactNativeWebView.postMessage(${updateDoc.G_RESPCODE});
                          }, 100);
                        
                          
                    });
                }())</script></body></html>`);
                        res.end();
                        /*  }) */
                    }
                });

            });

            // post the data
            post_req.write(post_data);
            post_req.end();
        });
    }
    catch (err) {
        res.status(500).send(err.message);
    }
}
module.exports = processPayment;