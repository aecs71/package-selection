const axiosReq = require('../../axiosreq');
const moment = require('moment');
const updateOrder = async (req, _result) => {

    const generateBillWithRetry = async (id, from, to) => {
        try {
            if (!from || !to) {
                console.error("From or to undefined");
                throw Error("There was an issue with the transaction,Any amount debited will be reversed with 7 business days.Contact your cable operator.")
            }
            const reqData = { "customer_id": id, "from_date": from, "period": 1, "to_date": to };
            const bill = await axiosReq.bixMobileRequest('balance/save-edited-bill', reqData,4);
            if(!bill)
                throw Error("Transaction Failed");
            return bill;

        }
        catch (error) {
            throw error;
        }
    }
    const recordPaymentWithRetry = async (id, TXNAMOUNT) => {
        try {
            let timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
            const reqData = [{
                "comment": "Online Payment", "customer_id": id, "discount_amount": 0.0,
                "local_id": 3, "paid_amount": TXNAMOUNT, "payment_amount": TXNAMOUNT, "payment_mode": "1",
                "record_timestamp": timestamp, "source_name": ""
            }]
            const payment = await axiosReq.bixMobileRequest('cable/payments/store', reqData,8);
            const resp=payment?payment.response:[];
            if(!payment)
                throw Error("Transaction failed.")
            if(Array.isArray(resp)&&resp[0] &&resp[0].res && resp[0].res.status_code==0){
                console.error("record payment failed: not autorised");
                throw Error("Transaction failed");
            }
            const statusCode=payment?payment.status_code:0
            if(statusCode!=1)
                throw Error("Transaction failed");
            return payment.data;
        }
        catch (error) {
            throw error;
        }
    }
    const bix = req.bix;
    try {
        const Credentials = bix.getSchema('credentials');
        const Orders = bix.getSchema('order');
        const { TXNID, BANKTXNID, ORDERID, TXNAMOUNT, STATUS, TXNTYPE, GATEWAYNAME, RESPCODE, RESPMSG,
            BANKNAME, PAYMENTMODE, REFUNDAMT, TXNDATE } = _result;
        const cookieObj = await Credentials.findOne({ key: 'cookie' }, { value: 1, _id: 0 });
        const csrfObj = await Credentials.findOne({ key: 'csrf' });
        const ordersData = await Orders.findOne({ orderId: ORDERID }) || {};
        const { from, to,custId } = ordersData;
        const cookie = cookieObj ? cookieObj.value : '';
        const xsrf = cookie.split(';')[0]
        const csrf = csrfObj ? csrfObj.value : ''
        var session = null;
        // var db = bix.mongoose.connection;
        if (RESPCODE == '01') {
            const updateStatus = await Orders.findOneAndUpdate({ orderId: _result.ORDERID }, {
                $set: {
                    txnStatus: STATUS, G_TXNID: TXNID, G_BANKTXNID: BANKTXNID,
                    G_TXNTYPE: TXNTYPE, G_GATEWAYNAME: GATEWAYNAME, G_RESPCODE: RESPCODE, G_RESPMSG: RESPMSG,
                    G_BANKNAME: BANKNAME, G_PAYMENTMODE: PAYMENTMODE, G_REFUNDAMT: REFUNDAMT, G_TXNDATE: TXNDATE,
                    G_TXNAMOUNT: TXNAMOUNT
                }
            });
            const billGenerateStatus = await generateBillWithRetry(custId, from, to);
            const recordPaymentStatus = await recordPaymentWithRetry(custId, TXNAMOUNT);
            const billGenerateUpdate=await  Orders.findOneAndUpdate({ orderId: _result.ORDERID }, {
                $set: { recordPaymentResp:recordPaymentStatus,generateBillResp:billGenerateStatus}
            }, { new: true });
            return billGenerateUpdate;
        }
        else {
            const updateStatus = await Orders.findOneAndUpdate({ orderId: _result.ORDERID }, {
                $set: {
                    txnStatus: STATUS, G_TXNID: TXNID, G_BANKTXNID: BANKTXNID,
                    G_TXNTYPE: TXNTYPE, G_GATEWAYNAME: GATEWAYNAME, G_RESPCODE: RESPCODE, G_RESPMSG: RESPMSG,
                    G_BANKNAME: BANKNAME, G_PAYMENTMODE: PAYMENTMODE, G_REFUNDAMT: REFUNDAMT, G_TXNDATE: TXNDATE,
                    G_TXNAMOUNT: TXNAMOUNT
                }
            },{new:true});
            return updateStatus;
        }
    }
    catch (error) {
        throw error;
    }

    
    const updateDatabasewithRetry = async () => {
        try {
            const Orders = bix.getSchema('order');

        }
        catch (error) {
            throw error;
        }
    }
}
module.exports = updateOrder;