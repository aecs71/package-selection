var bodyParser = require('body-parser');
var express = require('express');


function dynamicRouter(bix) {
  var router = express.Router();
  router.use(bodyParser.json({}));
  router.use(bodyParser.urlencoded({ extended: true }));
  router.use(function (req, res, next) {
    req.bix = bix;
    next();
  });
  router.get('/recharge-status', require('./recharge/rechargeStatus'))
  router.post('/search-customer',require('./customers/searchCustomer'))
  router.get('/payment', require('./payment/preparePayment'));
  router.all('/callback',require('./payment/processPayment'));
  return router;
}
module.exports = dynamicRouter;