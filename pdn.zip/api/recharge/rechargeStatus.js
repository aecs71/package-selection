
async function fetchRechargeStatusByDate(req, res) {
    var bix = req.bix;
    var Collections = bix.getSchema('collection');
    try{
       const pipeline=[
            {
               "$addFields": {
                  "indiaDay": {
                    "$dayOfMonth": { "date": "$time", "timezone": "+05:30" }
                  },
                  "timeStamp":{"$dateToString": { "format": "%Y-%m-%d  %H:%M:%S", "date": "$time", "timezone": "+05:30" }}
               }
           },{"$match":{ 
                   "indiaDay": new Date().getDate(),
               }},{ "$sort" : { "time" : -1} }]
        const rechargeData=await Collections.aggregate(pipeline);
        res.send(rechargeData);
    }
    catch(err){
        return res.status(500).send(`There was a problem fetching the recharge status`);
    }
   


}

module.exports = fetchRechargeStatusByDate;