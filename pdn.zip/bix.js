const path=require('path');
const _=require('lodash');
const fs=require('fs');
function Bix(){
this.options={};
this.list={};
this.set('name','Bix');
this.set('env',process.env.NODE_ENV ||'development');
this.set('port',process.env.PORT || "3000");
this.set('host',process.env.HOST || '192.168.43.61');
this.set('web host',process.env.WEB_HOST||'www.pubghub.in');
this.set('web port',process.env.WEB_PORT||'443');
this.set('ssl',process.env.SSL||true);
this.set('ssl port',process.env.SSL_PORT||'3000');
this.mongoose=require('mongoose');
}
_.extend(Bix.prototype,require('./lib/options'));
Bix.prototype.openDatabaseConnection=require('./lib/openDatabaseConnection');
Bix.prototype.initExpressApp=require('./lib/initExpressApp');
Bix.prototype.getSchema=require('./lib/getSchema');
Bix.prototype.start=require('./lib/start');
Bix.prototype.fetchBixCustomerReport=require('./lib/fetchBixUserReport');
Bix.prototype.import=function(dirname){
    var initialPath=path.join(__dirname,dirname);
   
    function doImport(fromPath){
        var imported={};
        fs.readdirSync(fromPath).forEach((name)=>{
            var fsPath=path.join(fromPath,name);
            var ext=path.extname(name);
            var base=path.basename(name,ext);
            imported[base]=require(fsPath);
        });
        return imported;
    }
      return doImport(initialPath);

}
module.exports=new Bix();