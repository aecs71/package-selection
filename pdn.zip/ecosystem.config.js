module.exports = {
  apps : [{
    name: 'bix42 node',
    script: 'index.js',

    // Options reference: https://pm2.io/doc/en/runtime/reference/ecosystem-file/
    args: 'one two',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'development',
      SSL: 'true',
      SSL_KEY: "./cert/pubghub.key",
      SSL_CERT: "./cert/pubghub.cert",
      SSL_PORT: "3001",
      PAYTM_DEV_MID: "RWxxBA56792291287425",
      PAYTM_DEV_KEY: "Rd!oa%5%Z9pG_#4V",
      PAYTM_DEV_WEB: "WEBSTAGING",
      JWT_SECRET: "Rqh%4Cd)9&"
    },
    env_production: {
      NODE_ENV: 'production',
      SSL: 'TRUE',
      SSL_PORT: "3000",
      JWT_SECRET: "Rqh%4Cd)9&",
      PAYTM_MID: "ywFQln38943121478235",
      PAYTM_WEB: "DEFAULT",
      PAYTM_KEY: "YQLX3tOHj6UP781P"
    }
  }],

  deploy: {
    production: {
      user: 'node',
      host: '212.83.163.1',
      ref: 'origin/master',
      repo: 'git@github.com:repo.git',
      path: '/var/www/production',
      'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env production'
    }
  }
};
