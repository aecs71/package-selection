

const config = {
    DEV: { host: 'http://192.168.0.103:3000' },
    PROD: {host:'https://recharge.pubghub.in'}
}

if (__DEV__) {
   module.exports=config.DEV
}
else {
    module.exports= config.PROD
}