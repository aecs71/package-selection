import { AsyncStorage } from 'react-native';
export const AUTH_KEY = "id_token";
export async function saveToken(value) {
    try {
        AsyncStorage.setItem(AUTH_KEY, value);
    }
    catch (err) {
      throw err;
    }
}
export const onSignOut = () => AsyncStorage.removeItem(AUTH_KEY);
export const isSignedIn = () => {
    return new Promise((resolve, reject) => {
        AsyncStorage.getItem(AUTH_KEY).then(res => {
            res ? resolve(res) : reject(false);
        }).catch(err => reject(err));
    })
}