export default strings={
Email_Required:'Email is required',
Password_Required:'Password is required',
Mobile_Required:'Mobile no. is required',
Name_Required:'Name is required',
Amount_Required:'Amount is required',
Mobile_Incorrect:'Mobile no is incorrect',
Email_Incorrect:'Email  is not valid',
Password_Match:'Password and confirm password doesnot match',
Pasword_Length:'Password should have minimum 8 characters',
Email_Regex:/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
Mobile_Regex:/^\d{10}$/
}