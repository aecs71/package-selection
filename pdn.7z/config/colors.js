const colors = {
    BLACK: "#000",
    WHITE: "#FFF",
    DODGER_BLUE: "#428AF8",
    SILVER: "#BEBEBE",
    TORCH_RED: "#F8262F",
    MISCHKA: "#E5E4E6",
    BACKGROUND_LIGHT:"#dae1e7",
    PRIMARY_COLOR:"#3C5A99",
    SECONDARY_GREEN:'#4DB6AC',
    SECONDARY_BROWN:'#9C4100'
  };
  
  export default colors;