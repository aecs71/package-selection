import * as WebBrowser from 'expo-web-browser';
import React, { useState } from 'react';
import {
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View, TextInput, Alert,ActivityIndicator
} from 'react-native';
import axios from 'axios';
import { MonoText } from '../components/StyledText';
import colors from '../config/colors';
import Button from '../components/Button';
import config from '../config';
export default function HomeScreen(props) {
  const [value, setValue] = useState("");
  const [searchResult, setSearchResult] = useState({ customerDetails: {}, bill: {} });
  const [loader,setLoader]=useState(false);
  const total=(Number(searchResult.bill.total) + Number(searchResult.bill.previous_balance)).toFixed(2);
  proceedPayment = () => {
    console.log(props)
    //props.navigation.navigate('PaymentConfirmation', { respCode: '0' })

     props.navigation.navigate('Payment', {
       amount: Math.round(Number(searchResult.bill.total) + Number(searchResult.bill.previous_balance)), cardNo: searchResult.customerDetails.card_no,
       stbNo: searchResult.customerDetails.stb_no, id: searchResult.customerDetails.id,from:searchResult.bill.from,
       to:searchResult.bill.to
     }) 
  }
  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}>
        <View style={styles.welcomeContainer}>
          <TextInput style={styles.textInput}
            autoCorrect={false}
            selectTextOnFocus={true}
            returnKeyType='search'
            placeholder="Enter Stb No or Card No."
            value={value}
            onChangeText={(value) =>{ 
              if(!value)
              setSearchResult({customerDetails:{},bill:{}})
              setValue(value)}}
            onSubmitEditing={() => handleSearchSubmit(value, setSearchResult,setLoader)}
          />
        </View>
        <ActivityIndicator size="large" color="#0000ff" animating={loader} />
       { searchResult.customerDetails.name && <View>
          <View style={styles.getStartedContainer}>
            {/*  <DevelopmentModeNotice />
          <Text style={styles.getStartedText}>Gget started by opening</Text>

          <View
            style={[styles.codeHighlightContainer, styles.homeScreenFilename]}>
            <MonoText>screens/HomeScreen.js</MonoText>
          </View>

          <Text style={styles.getStartedText}>
            Change this text and your app will automatically reload
          </Text> */}
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Name:</MonoText>
              <MonoText>{searchResult.customerDetails.name}</MonoText>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Card No:</MonoText>
              <MonoText>{searchResult.customerDetails.card_no}</MonoText>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Stb No:</MonoText>
              <MonoText>{searchResult.customerDetails.stb_no}</MonoText>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Current Expiry Date:</MonoText>
              <MonoText>{searchResult.customerDetails.last_bill_date}</MonoText>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Bill from:</MonoText>
              <MonoText>{searchResult.bill.from}</MonoText>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Bill to:</MonoText>
              <MonoText>{searchResult.bill.to}</MonoText>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Current Bill:</MonoText>
              <MonoText>{searchResult.bill.total}</MonoText>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Previous Due:</MonoText>
              <MonoText>{searchResult.bill.previous_balance}</MonoText>
            </View>
            <View style={{ flexDirection: 'row' }}>
              <MonoText>Total:</MonoText>
              <MonoText>{total}</MonoText>
            </View>
          </View>
          <View style={styles.helpContainer}>
            {/*           <TouchableOpacity onPress={handleHelpPress} style={styles.helpLink}>
            <Text style={styles.helpLinkText}>
              Help, it didn’t automatically reload!
            </Text>
          </TouchableOpacity> */}
            <Button
              label={"Pay "+total}
              onPress={proceedPayment}
            />
          </View>
        </View>}
      </ScrollView>

      <View style={styles.tabBarInfoContainer}>
        <Text style={styles.tabBarInfoText}>
          This is a tab bar. You can edit it in:
        </Text>

        <View
          style={[styles.codeHighlightContainer, styles.navigationFilename]}>
          <MonoText style={styles.codeHighlightText}>
            navigation/MainTabNavigator.js
          </MonoText>
        </View>
      </View>
    </View>
  );
}
function handleSearchSubmit(value, setSearchResult,setLoader) {
  setLoader(true)
  axios.post(`${config.host}/api/search-customer`, {
    searchTxt: value
  }).then(res => {
    if (res.data) {
      setLoader(false)
      setSearchResult(res.data)
    }
  }).catch(err => {
    setLoader(false);
    let errorMsg = '';
    if (err.response && err.response.data)
      errorMsg = err.response.data;
    else
      errorMsg = err.message
    Alert.alert('Error', errorMsg)
  })
}
HomeScreen.navigationOptions = {
  header: null,
};


/* function DevelopmentModeNotice() {
  if (__DEV__) {
    const learnMoreButton = (
      <Text onPress={handleLearnMorePress} style={styles.helpLinkText}>
        Learn more
      </Text>
    );

    return (
      <Text style={styles.developmentModeText}>
        Development mode is enabled: your app will be slower but you can use
        useful development tools. {learnMoreButton}
      </Text>
    );
  } else {
    return (
      <Text style={styles.developmentModeText}>
        You are not in development mode: your app will run at full speed.
      </Text>
    );
  }
}

function handleLearnMorePress() {
  WebBrowser.openBrowserAsync(
    'https://docs.expo.io/versions/latest/workflow/development-mode/'
  );
}

function handleHelpPress() {
  WebBrowser.openBrowserAsync(
    'https://docs.expo.io/versions/latest/workflow/up-and-running/#cant-see-your-changes'
  );
} */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  developmentModeText: {
    marginBottom: 20,
    color: 'rgba(0,0,0,0.4)',
    fontSize: 14,
    lineHeight: 19,
    textAlign: 'center',
  },
  contentContainer: {
    paddingTop: 30,
  },
  welcomeContainer: {
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  textInput: {
    height: 35,
    borderColor: colors.SILVER,
    borderBottomWidth: StyleSheet.hairlineWidth,
    marginBottom: 20,
    width: '90%',
    borderWidth: 0.7,
    borderRadius: 10,
    paddingLeft: 15,
    elevation: 0.6
  },
  welcomeImage: {
    width: 100,
    height: 80,
    resizeMode: 'contain',
    marginTop: 3,
    marginLeft: -10,
  },
  getStartedContainer: {
    alignItems: 'center',
    marginHorizontal: 50,
  },
  homeScreenFilename: {
    marginVertical: 7,
  },
  codeHighlightText: {
    color: 'rgba(96,100,109, 0.8)',
  },
  codeHighlightContainer: {
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: 3,
    paddingHorizontal: 4,
  },
  getStartedText: {
    fontSize: 17,
    color: 'rgba(96,100,109, 1)',
    lineHeight: 24,
    textAlign: 'center',
  },
  tabBarInfoContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: { width: 0, height: -3 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
      },
      android: {
        elevation: 20,
      },
    }),
    alignItems: 'center',
    backgroundColor: '#fbfbfb',
    paddingVertical: 20,
  },
  tabBarInfoText: {
    fontSize: 17,
    color: 'rgba(96,100,109, 1)',
    textAlign: 'center',
  },
  navigationFilename: {
    marginTop: 5,
  },
  helpContainer: {
    marginTop: 15,
    alignItems: 'center',

  },
  helpLink: {
    paddingVertical: 15,
  },
  helpLinkText: {
    fontSize: 14,
    color: '#2e78b7',
  },
});
