import * as WebBrowser from 'expo-web-browser';
import React, { useState } from 'react';
import { WebView } from 'react-native-webview';
import {
    Image,
    Platform,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View, TextInput, Alert
} from 'react-native';
import axios from 'axios';
import { MonoText } from '../components/StyledText';
import colors from '../config/colors';
import Button from '../components/Button';
import config from '../config';
export default function HomeScreen(props) {
    function handleMessage(data) {
        console.log(data);
        paymentState.navigation.navigate('PaymentConfirmation', { respCode: data })

    }
    const [paymentState, setPaymentState] = useState(props);
    const amount = paymentState.navigation.getParam('amount');
    const stbNo = paymentState.navigation.getParam('stbNo');
    const cardNo = paymentState.navigation.getParam('cardNo');
    const id = paymentState.navigation.getParam('id')
    const from = paymentState.navigation.getParam('from');
    const to = paymentState.navigation.getParam('to');
    return (
        <WebView
            source={{ uri: `${config.host}/api/payment?amount=${amount}&stbNo=${stbNo}&cardNo=${cardNo}&id=${id}&from=${from}&to=${to}` }}
            style={{ marginTop: 20 }}
            onMessage={(evt) => {
                console.log(evt);
                handleMessage(evt.nativeEvent.data);
            }}
            javaScriptEnabled={true}
        />
    );
}
