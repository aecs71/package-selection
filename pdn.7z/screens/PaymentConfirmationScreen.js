import React, { useState, useEffect } from 'react';
import { View, Image, Text, BackHandler } from 'react-native';
export default function PaymentConfirmation(props) {
    const [paymentState, setPaymentStatus] = useState(props);
    const paymentStatus = (paymentState.navigation.getParam('respCode') == '1') ? true : false
    const txnId=paymentState.navigation.getParam('txnId');
    useEffect(() => {
         function handleBackPress() {
             props.navigation.navigate('Home'); // works best when the goBack is async
             return true;
         }
         BackHandler.addEventListener('hardwareBackPress', handleBackPress);
         return function cleanup() {
             BackHandler.removeEventListener('hardwareBackPress', this.handleBackPress);
         }
    })
    return (<View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>{paymentStatus ? (
        <View>
            <Image source={require('../assets/images/tick.png')} style={{ height: 120, width: 120,marginHorizontal:20 }} />
            <Text style={{marginTop:10}}>Your Payment is successful</Text>
        </View>) :
        (<View>
            <Image source={require('../assets/images/cross.png')} style={{ height: 120, width: 120,marginHorizontal:20 }} />
            <Text style={{marginTop:10}}>Your Payment has failed</Text> 
        </View>)}
    </View>)
}